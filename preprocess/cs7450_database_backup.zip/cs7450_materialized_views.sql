CREATE MATERIALIZED VIEW "public"."related_tags_with_first_post_materialized"
AS 
 SELECT w.source_tag,
    w.tag,
    w.count,
    w.rank,
    p.post_id
   FROM (( SELECT z.source_tag,
            z.tag,
            z.count,
            z.rank,
            a.post_id,
            row_number() OVER (PARTITION BY z.source_tag, z.tag ORDER BY a.post_id) AS no
           FROM ((( SELECT x.tag AS source_tag,
                    y.tag,
                    count(*) AS count,
                    row_number() OVER (PARTITION BY x.tag ORDER BY count(*) DESC) AS rank
                   FROM (post_tags_sampled x
                     JOIN post_tags_sampled y ON (((x.post_id = y.post_id) AND ((x.tag)::text <> (y.tag)::text))))
                  GROUP BY x.tag, y.tag) z
             JOIN post_tags_sampled a ON (((z.source_tag)::text = (a.tag)::text)))
             JOIN post_tags_sampled b ON ((((z.tag)::text = (b.tag)::text) AND (a.post_id = b.post_id))))
          WHERE (z.rank <= 10)) w
     LEFT JOIN posts_sampled p ON ((w.post_id = p.post_id)))
  WHERE (w.no <= 1)
  ORDER BY w.source_tag, w.rank;
WITH DATA;

ALTER MATERIALIZED VIEW "related_tags_with_first_post_materialized" OWNER TO "cs7450";